#ifndef SHOW_TABLES_EXECUTOR_H
#define SHOW_TABLES_EXECUTOR_H
#include "sql_event.h"
int ShowTableExecute(SQLStageEvent *sqlEvent);
#endif  // SHOW_TABLES_EXECUTOR_H