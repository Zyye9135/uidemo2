#ifndef RESOLVE_STAGE_H
#define RESOLVE_STAGE_H
#include "sql_event.h"
int ResolveStageHandleRequest(SQLStageEvent *sqlEvent);
#endif