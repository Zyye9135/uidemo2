#ifndef PARSE_STAGE_H
#define PARSE_STAGE_H
#include "sql_event.h"
int ParseStageHandleRequest(SQLStageEvent *sqlEvent);
#endif /* SQL_STAGE_EVENT_H */
