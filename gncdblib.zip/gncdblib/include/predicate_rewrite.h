#ifndef PREDICATE_REWRITE_H
#define PREDICATE_REWRITE_H
#include "logical_operator.h"
int PredicateRewriter(LogicalOperator *oper, bool *changeMade);
#endif  // PREDICATE_REWRITE_H