#ifndef DROP_TABLE_EXECUTOR_H
#define DROP_TABLE_EXECUTOR_H
#include "sql_event.h"
int DropTableExecute(SQLStageEvent *sqlEvent);
#endif  // DROP_TABLE_EXECUTOR_H