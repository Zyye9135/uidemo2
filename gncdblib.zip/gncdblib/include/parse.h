#ifndef PARSE_H
#define PARSE_H
#include "parse_defs.h"
int parse(const char *st, ParsedSqlResult *sqlResult);
#endif
